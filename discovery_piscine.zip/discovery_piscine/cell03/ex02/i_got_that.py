#!/usr/bin/env python3

# chmod +x i_got_that.py.

word1 = input("What you gotta say? : " )


while word1 != "STOP":
    
    word1 = input("I got that! Anything else? : " )

    if word1 == "STOP":
     break
