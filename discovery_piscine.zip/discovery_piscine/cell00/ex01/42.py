print(42)
print()
