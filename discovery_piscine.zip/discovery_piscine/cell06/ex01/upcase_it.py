#!/usr/bin/env python3

# chmod +x parameter_matching.py.

word = "hello"

def hello():
    print(word.upper())
    return 

hello()