#!/usr/bin/env python3

# chmod +x parameter_matching.py.


def upcase_it(word):
    print(word.upper())


print(upcase_it("hello"))