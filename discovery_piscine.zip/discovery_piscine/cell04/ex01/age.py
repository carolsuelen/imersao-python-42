#!/usr/bin/env python3

# chmod +x age.py.

age = int(input("Please tell me your age: "))
number1  = age + 10
number2 = age + 20
number3 = age + 30

print("You are currently " + str(age) + " years old.")
print("In 10 years, you'll be " + str(number1) + " years old.")
print("In 20 years, you'll be " + str(number2) + " years old.")
print("In 30 years, you'll be " + str(number3) + " years old.")