#!/usr/bin/env python3

# chmod +x upcase_it.py.

word = input("Give me a word: ")

print(word.upper())
