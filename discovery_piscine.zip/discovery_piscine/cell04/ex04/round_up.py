#!/usr/bin/env python3

# chmod +x round_up.py.

import math


number = float(input("Give me a number: "))
rounded_up = math.ceil(number)

print(rounded_up)