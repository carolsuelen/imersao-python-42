#!/usr/bin/env python3

# chmod +x up_low.py.

word = input()

change_word = word.swapcase()
print(change_word)