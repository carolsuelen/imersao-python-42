#!/usr/bin/env python3

# chmod +x ispassword.py.


password = "Python is awesome"

valor = input()

if password == valor:
    print("ACCESS GRANTED")
else:
    print("ACCESS DENIED.")