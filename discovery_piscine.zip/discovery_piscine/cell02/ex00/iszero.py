#!/usr/bin/env python

# chmod +x iszero.py.

number = int(input())

if number == 0:
 print("This number is equal to zero.")
else:
 print("This number is different from zero.")