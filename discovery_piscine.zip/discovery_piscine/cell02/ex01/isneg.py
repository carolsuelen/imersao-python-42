#!/usr/bin/env python3

# chmod +x isneg.py.

number = int(input())

if number < 0:
 print("This number is negative.")
elif number > 0:
 print("This number is positive")
elif number == 0:
 print("This number is both positive and negative.")