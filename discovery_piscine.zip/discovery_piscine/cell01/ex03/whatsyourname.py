
name = input("Hey, what's your first name? : ").strip()

last_name = input("And your last name? :  ").strip()

print("Well, pleased to meet you, " + name + " " + last_name + ".")
