first_name = "Carolina"
last_name = "Attili"

print(first_name + " " + last_name)
