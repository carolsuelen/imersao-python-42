first_name = "Carolina"
last_name = "Attili"
whole_name = first_name + " " + last_name

print(whole_name)

