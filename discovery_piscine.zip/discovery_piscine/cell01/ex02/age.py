age = 34
number = 42
my_age = age + number

print(my_age)