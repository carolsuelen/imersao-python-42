#!/usr/bin/env python3

# chmod +x create_array.py.

my_list = [2, 8, 9, 48, 8, 22, -12, 2]


print(my_list)