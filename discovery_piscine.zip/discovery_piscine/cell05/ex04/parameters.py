#!/usr/bin/env python3


import sys

# print(sys.argv[0])

len(sys.argv)
print(f"Number of parameters: {len(sys.argv)-1}.")
sys.exit()