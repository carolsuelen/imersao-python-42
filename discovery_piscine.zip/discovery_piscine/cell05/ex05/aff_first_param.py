#!/usr/bin/env python3


import sys


if len(sys.argv) == 1:
    print("none")
    sys.exit()
else:
    print(sys.argv[1])
